export default class Pais {
    id?: number;
    nombre: string = "";
    eliminado!: boolean;
}
