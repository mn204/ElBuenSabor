export default class UsuarioCliente {
    id?: number;

    email: string = "";
    firebaseUid: string = "";
    eliminado!: boolean;
}