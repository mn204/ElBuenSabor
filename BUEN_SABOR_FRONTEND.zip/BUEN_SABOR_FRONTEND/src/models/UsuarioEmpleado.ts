export default class UsuarioEmpleado {
    id?: number;
    email: string = "";
    firebaseUid: string = "";
    eliminado!: boolean;
}