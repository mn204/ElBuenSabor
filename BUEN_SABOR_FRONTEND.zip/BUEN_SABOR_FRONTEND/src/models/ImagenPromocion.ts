export default class ImagenPromocion {
    id?: number;
    denominacion: string = "";
}