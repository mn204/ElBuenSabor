enum FormaPago {
    EFECTIVO = "EFECTIVO",
    TARJETA = "TARJETA",
    MERCADO_PAGO = "MERCADO_PAGO"
}

export default FormaPago;