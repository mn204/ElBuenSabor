enum TipoPromocion {
    HAPPYHOUR = "HAPPYHOUR",
    PROMOCION = "PROMOCION"
}

export default TipoPromocion;