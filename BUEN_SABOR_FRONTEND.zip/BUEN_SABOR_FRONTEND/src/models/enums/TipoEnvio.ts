enum TipoEnvio {
    DELIVERY = "DELIVERY",
    TAKEAWAY = "TAKEAWAY"
}

export default TipoEnvio;