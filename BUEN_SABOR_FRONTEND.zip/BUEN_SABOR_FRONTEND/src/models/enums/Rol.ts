enum Rol {
    ADMIN = "ADMIN",
    COCINERO = "COCINERO",
    CAJERO = "CAJERO",
    DELIVERY = "DELIVERY",
    CLIENTE = "CLIENTE"
}

export default Rol;