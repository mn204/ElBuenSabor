enum Estado {
    PREPARACION = "PREPARACION",
    PENDIENTE = "PENDIENTE",
    CANCELADO = "CANCELADO",
    RECHAZADO = "RECHAZADO",
    ENTREGADO = "ENTREGADO"
}

export default Estado;