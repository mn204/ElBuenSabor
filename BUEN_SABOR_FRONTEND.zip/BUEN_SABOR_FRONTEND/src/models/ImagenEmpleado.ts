export default class ImagenEmpleado {
    id?: number;
    denominacion: string = "";
}