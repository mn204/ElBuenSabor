export default class UnidadMedida {
    id?: number;
    denominacion: string = "";
    eliminado!: boolean;
}