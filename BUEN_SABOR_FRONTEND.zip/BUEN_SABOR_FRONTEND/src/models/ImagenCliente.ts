export default class ImagenCliente {
    id?: number;
    denominacion: string = "";
}