package com.lab4.buen_sabor_backend.model.enums;

public enum Estado {
    PREPARACION,
    PENDIENTE,
    CANCELADO,
    RECHAZADO,
    ENTREGADO,
}
