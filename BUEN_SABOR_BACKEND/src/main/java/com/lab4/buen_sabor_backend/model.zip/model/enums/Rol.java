package com.lab4.buen_sabor_backend.model.enums;

public enum Rol {

    COCINERO,
    CAJERO,
    DELIVERY,
    ADMINISTRADOR,
    CLIENTE
}
